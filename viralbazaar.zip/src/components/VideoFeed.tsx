import React, { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Video, Product } from '../types';
import { Heart, MessageCircle, Share2, ShoppingCart, Music, Play } from 'lucide-react';
import { motion, useScroll, useTransform } from 'motion/react';
import { cn } from '../lib/utils';

interface VideoFeedProps {
  onAddToCart: (product: Product) => void;
}

const MOCK_VIDEOS: Video[] = [
  {
    id: '1',
    creatorId: 'c1',
    videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    thumbnailUrl: '',
    caption: 'Check out these new neon sneakers! 👟✨ #fashion #neon',
    productIds: ['p1'],
    likesCount: 12400,
    commentsCount: 450,
    sharesCount: 890,
    createdAt: new Date(),
  },
  {
    id: '2',
    creatorId: 'c2',
    videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    thumbnailUrl: '',
    caption: 'Minimalist aesthetic for the weekend. 🖤 #minimal #style',
    productIds: ['p2'],
    likesCount: 8900,
    commentsCount: 230,
    sharesCount: 120,
    createdAt: new Date(),
  }
];

const MOCK_PRODUCTS: Record<string, Product> = {
  'p1': {
    id: 'p1',
    name: 'Neon Glow Sneakers',
    price: 129.99,
    description: 'High-performance sneakers with integrated LED lighting.',
    image: 'https://picsum.photos/seed/sneakers/400/400',
    creatorId: 'c1',
    stock: 50,
    category: 'Footwear'
  },
  'p2': {
    id: 'p2',
    name: 'Classic Black Blazer',
    price: 89.00,
    description: 'A timeless piece for any wardrobe.',
    image: 'https://picsum.photos/seed/blazer/400/400',
    creatorId: 'c2',
    stock: 20,
    category: 'Apparel'
  }
};

export default function VideoFeed({ onAddToCart }: VideoFeedProps) {
  const [videos, setVideos] = useState<Video[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // In a real app, we'd fetch from Firestore
    // For now, use mock data if Firestore is empty
    const q = query(collection(db, 'videos'), orderBy('createdAt', 'desc'), limit(10));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (snapshot.empty) {
        setVideos(MOCK_VIDEOS);
      } else {
        setVideos(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Video)));
      }
    });

    return () => unsubscribe();
  }, []);

  return (
    <div 
      ref={containerRef}
      className="h-[calc(100vh-64px)] md:h-screen overflow-y-scroll snap-y snap-mandatory hide-scrollbar"
    >
      {videos.map((video) => (
        <VideoItem 
          key={video.id} 
          video={video} 
          onAddToCart={onAddToCart} 
          product={MOCK_PRODUCTS[video.productIds[0]]}
        />
      ))}
    </div>
  );
}

function VideoItem({ video, onAddToCart, product }: { video: Video, onAddToCart: (p: Product) => void, product?: Product, key?: string }) {
  const [liked, setLiked] = useState(false);
  const [videoError, setVideoError] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !videoError) {
          videoRef.current?.play().catch(() => {});
        } else {
          videoRef.current?.pause();
        }
      },
      { threshold: 0.5 }
    );

    if (videoRef.current) {
      observer.observe(videoRef.current);
    }

    return () => observer.disconnect();
  }, [videoError]);

  return (
    <div className="h-full w-full snap-start relative bg-neutral-900 flex items-center justify-center overflow-hidden">
      {!videoError ? (
        <video
          ref={videoRef}
          src={video.videoUrl}
          className="h-full w-full object-cover"
          loop
          muted
          playsInline
          onError={() => setVideoError(true)}
        />
      ) : (
        <div className="h-full w-full flex flex-col items-center justify-center bg-neutral-800 text-white/20 p-10 text-center">
          <Play size={64} className="mb-4" />
          <p className="font-mono text-xs uppercase tracking-widest">Video unavailable</p>
          <p className="text-[10px] mt-2 max-w-[200px]">The content could not be loaded. Please try again later.</p>
        </div>
      )}

      {/* Overlay Content */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/60 pointer-events-none" />

      {/* Right Actions */}
      <div className="absolute right-4 bottom-24 flex flex-col items-center space-y-6 z-10">
        <button 
          onClick={() => setLiked(!liked)}
          className="flex flex-col items-center"
        >
          <div className={cn(
            "p-3 rounded-full bg-white/10 backdrop-blur-md transition-all",
            liked ? "text-red-500 scale-110" : "text-white"
          )}>
            <Heart fill={liked ? "currentColor" : "none"} size={28} />
          </div>
          <span className="text-[10px] font-bold mt-1 uppercase tracking-tighter">
            {(video.likesCount / 1000).toFixed(1)}K
          </span>
        </button>

        <button className="flex flex-col items-center">
          <div className="p-3 rounded-full bg-white/10 backdrop-blur-md text-white">
            <MessageCircle size={28} />
          </div>
          <span className="text-[10px] font-bold mt-1 uppercase tracking-tighter">
            {video.commentsCount}
          </span>
        </button>

        <button className="flex flex-col items-center">
          <div className="p-3 rounded-full bg-white/10 backdrop-blur-md text-white">
            <Share2 size={28} />
          </div>
          <span className="text-[10px] font-bold mt-1 uppercase tracking-tighter">
            {video.sharesCount}
          </span>
        </button>
      </div>

      {/* Bottom Info & Shoppable Tag */}
      <div className="absolute left-4 right-20 bottom-8 z-10">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 rounded-full border-2 border-orange-500 overflow-hidden">
            <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${video.creatorId}`} alt="Creator" />
          </div>
          <div>
            <h3 className="font-bold text-sm tracking-tight">@creator_{video.creatorId}</h3>
            <div className="flex items-center text-[10px] text-white/60 uppercase tracking-widest">
              <Music size={10} className="mr-1" />
              <span>Original Audio</span>
            </div>
          </div>
        </div>

        <p className="text-sm text-white/90 line-clamp-2 mb-6 max-w-md">
          {video.caption}
        </p>

        {product && (
          <motion.div 
            initial={{ x: -20, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            className="flex items-center bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-3 max-w-xs group cursor-pointer"
            onClick={() => onAddToCart(product)}
          >
            <img src={product.image} alt={product.name} className="w-12 h-12 rounded-lg object-cover mr-3" />
            <div className="flex-1 min-w-0">
              <h4 className="text-xs font-bold truncate">{product.name}</h4>
              <p className="text-orange-500 font-black text-sm">${product.price}</p>
            </div>
            <div className="bg-orange-500 p-2 rounded-full group-hover:scale-110 transition-transform">
              <ShoppingCart size={16} className="text-white" />
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
