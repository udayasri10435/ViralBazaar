import React, { useState } from 'react';
import { User } from '../types';
import { aiService } from '../services/aiService';
import { Sparkles, Image as ImageIcon, Video, Music, Mic, Wand2, Loader2, Download, Key, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'react-hot-toast';

interface AIStudioProps {
  user: User;
  hasApiKey: boolean;
  onOpenKeySelector: () => void;
}

export default function AIStudio({ user, hasApiKey, onOpenKeySelector }: AIStudioProps) {
  const [activeTab, setActiveTab] = useState<'image' | 'video' | 'music' | 'tts' | 'analyze'>('image');
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  
  // Options
  const [aspectRatio, setAspectRatio] = useState<any>('1:1');
  const [imageSize, setImageSize] = useState<any>('1K');
  const [isPro, setIsPro] = useState(false);
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [sourceVideo, setSourceVideo] = useState<string | null>(null);
  const [isHighThinking, setIsHighThinking] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setResult(null);
    setAnalysisResult(null);
    try {
      let url = null;
      if (activeTab === 'image') {
        if (isPro) {
          if (!hasApiKey) {
            onOpenKeySelector();
            setLoading(false);
            return;
          }
          url = await aiService.generateImagePro(prompt, imageSize);
        } else {
          url = await aiService.generateImageFlash(prompt, aspectRatio);
        }
      } else if (activeTab === 'video') {
        if (!hasApiKey) {
          onOpenKeySelector();
          setLoading(false);
          return;
        }
        url = await aiService.generateVideo(prompt, aspectRatio === '16:9' ? '16:9' : '9:16', sourceImage || undefined);
      } else if (activeTab === 'music') {
        if (!hasApiKey) {
          onOpenKeySelector();
          setLoading(false);
          return;
        }
        url = await aiService.generateMusic(prompt, isPro);
      } else if (activeTab === 'tts') {
        url = await aiService.textToSpeech(prompt);
      } else if (activeTab === 'analyze') {
        if (sourceImage) {
          const res = await aiService.analyzeImage(prompt, sourceImage);
          setAnalysisResult(res.text);
        } else if (sourceVideo) {
          const res = await aiService.analyzeVideo(prompt, sourceVideo);
          setAnalysisResult(res.text);
        }
      }

      if (url) {
        setResult(url);
        toast.success('Generation complete!');
      } else if (analysisResult) {
        toast.success('Analysis complete!');
      } else if (activeTab !== 'analyze') {
        toast.error('Generation failed');
      }
    } catch (error) {
      console.error(error);
      toast.error('An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSourceVideo(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSourceImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <header className="mb-12 text-center">
        <div className="inline-flex items-center space-x-2 bg-orange-500/10 text-orange-500 px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest mb-4">
          <Sparkles size={14} />
          <span>Creator AI Studio</span>
        </div>
        <h1 className="text-5xl font-black tracking-tighter uppercase italic mb-4">Generate Viral Content</h1>
        <p className="text-white/40 max-w-2xl mx-auto">Use the world's most advanced AI models to create images, videos, and music for your next viral post.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-neutral-900 border border-white/10 rounded-3xl p-2 flex">
            {(['image', 'video', 'music', 'tts', 'analyze'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => { setActiveTab(tab); setResult(null); setAnalysisResult(null); }}
                className={`flex-1 flex items-center justify-center py-3 rounded-2xl transition-all ${activeTab === tab ? 'bg-white text-black font-bold' : 'text-white/40 hover:text-white'}`}
              >
                {tab === 'image' && <ImageIcon size={18} />}
                {tab === 'video' && <Video size={18} />}
                {tab === 'music' && <Music size={18} />}
                {tab === 'tts' && <Mic size={18} />}
                {tab === 'analyze' && <Search size={18} />}
              </button>
            ))}
          </div>

          <div className="bg-neutral-900 border border-white/10 rounded-3xl p-6 space-y-6">
            <div>
              <label className="block text-[10px] font-black text-white/40 uppercase tracking-widest mb-3">Prompt</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={`Describe the ${activeTab} you want to create...`}
                className="w-full bg-black border border-white/10 rounded-2xl p-4 text-sm h-32 focus:outline-none focus:border-orange-500 transition-colors resize-none"
              />
            </div>

            {activeTab === 'image' && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold">Pro Mode (Imagen 4)</span>
                  <button 
                    onClick={() => setIsPro(!isPro)}
                    className={`w-12 h-6 rounded-full transition-colors relative ${isPro ? 'bg-orange-500' : 'bg-white/10'}`}
                  >
                    <div className={`absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-transform ${isPro ? 'translate-x-6' : ''}`} />
                  </button>
                </div>
                
                {isPro ? (
                  <div>
                    <label className="block text-[10px] font-black text-white/40 uppercase tracking-widest mb-3">Image Size</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['1K', '2K', '4K'].map((size) => (
                        <button
                          key={size}
                          onClick={() => setImageSize(size)}
                          className={`py-2 rounded-xl text-xs font-bold border transition-all ${imageSize === size ? 'bg-white text-black border-white' : 'border-white/10 text-white/40 hover:border-white/40'}`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div>
                    <label className="block text-[10px] font-black text-white/40 uppercase tracking-widest mb-3">Aspect Ratio</label>
                    <div className="grid grid-cols-4 gap-2">
                      {['1:1', '3:4', '4:3', '9:16', '16:9'].map((ratio) => (
                        <button
                          key={ratio}
                          onClick={() => setAspectRatio(ratio)}
                          className={`py-2 rounded-xl text-[10px] font-bold border transition-all ${aspectRatio === ratio ? 'bg-white text-black border-white' : 'border-white/10 text-white/40 hover:border-white/40'}`}
                        >
                          {ratio}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {activeTab === 'video' && (
              <>
                <div>
                  <label className="block text-[10px] font-black text-white/40 uppercase tracking-widest mb-3">Aspect Ratio</label>
                  <div className="grid grid-cols-2 gap-2">
                    {['16:9', '9:16'].map((ratio) => (
                      <button
                        key={ratio}
                        onClick={() => setAspectRatio(ratio)}
                        className={`py-2 rounded-xl text-xs font-bold border transition-all ${aspectRatio === ratio ? 'bg-white text-black border-white' : 'border-white/10 text-white/40 hover:border-white/40'}`}
                      >
                        {ratio === '16:9' ? 'Landscape' : 'Portrait'}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-white/40 uppercase tracking-widest mb-3">Source Image (Optional)</label>
                  <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="video-source" />
                  <label 
                    htmlFor="video-source"
                    className="flex items-center justify-center border-2 border-dashed border-white/10 rounded-2xl p-4 cursor-pointer hover:border-orange-500/50 transition-colors"
                  >
                    {sourceImage ? (
                      <img src={sourceImage} className="h-20 w-auto rounded-lg" />
                    ) : (
                      <div className="text-center">
                        <ImageIcon size={24} className="mx-auto mb-2 text-white/20" />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Upload Image</span>
                      </div>
                    )}
                  </label>
                </div>
              </>
            )}

            {activeTab === 'analyze' && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-white/40 uppercase tracking-widest mb-3">Image</label>
                    <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="analyze-image" />
                    <label 
                      htmlFor="analyze-image"
                      className={`flex items-center justify-center border-2 border-dashed rounded-2xl p-4 cursor-pointer transition-colors ${sourceImage ? 'border-orange-500 bg-orange-500/5' : 'border-white/10 hover:border-white/20'}`}
                    >
                      {sourceImage ? (
                        <img src={sourceImage} className="h-16 w-auto rounded-lg" />
                      ) : (
                        <ImageIcon size={20} className="text-white/20" />
                      )}
                    </label>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-white/40 uppercase tracking-widest mb-3">Video</label>
                    <input type="file" accept="video/*" onChange={handleVideoUpload} className="hidden" id="analyze-video" />
                    <label 
                      htmlFor="analyze-video"
                      className={`flex items-center justify-center border-2 border-dashed rounded-2xl p-4 cursor-pointer transition-colors ${sourceVideo ? 'border-orange-500 bg-orange-500/5' : 'border-white/10 hover:border-white/20'}`}
                    >
                      {sourceVideo ? (
                        <Video size={20} className="text-orange-500" />
                      ) : (
                        <Video size={20} className="text-white/20" />
                      )}
                    </label>
                  </div>
                </div>
              </>
            )}

            {!hasApiKey && (activeTab === 'video' || (activeTab === 'image' && isPro) || activeTab === 'music') && (
              <button 
                onClick={onOpenKeySelector}
                className="w-full flex items-center justify-center space-x-2 bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-500 transition-all"
              >
                <Key size={18} />
                <span>Select API Key to Enable</span>
              </button>
            )}

            <button
              onClick={handleGenerate}
              disabled={loading || !prompt.trim()}
              className="w-full flex items-center justify-center space-x-2 bg-white text-black py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" /> : <Wand2 size={20} />}
              <span>{loading ? 'Generating...' : 'Generate Content'}</span>
            </button>
          </div>
        </div>

        {/* Preview */}
        <div className="lg:col-span-2">
          <div className="bg-neutral-900 border border-white/10 rounded-[40px] h-full min-h-[500px] flex flex-col overflow-hidden">
            <div className="p-6 border-b border-white/10 flex items-center justify-between">
              <h3 className="font-bold uppercase tracking-tighter">Preview</h3>
              {result && (
                <a href={result} download={`viralbazaar-${activeTab}`} className="text-xs font-bold text-orange-500 hover:text-white transition-colors">Download</a>
              )}
            </div>
            <div className="flex-1 flex items-center justify-center p-8 bg-black/40">
              {loading ? (
                <div className="text-center space-y-4">
                  <Loader2 size={48} className="animate-spin text-orange-500 mx-auto" />
                  <p className="font-mono text-xs uppercase tracking-widest text-white/40">AI is crafting your masterpiece...</p>
                </div>
              ) : result ? (
                <div className="w-full h-full flex items-center justify-center">
                  {activeTab === 'image' && <img src={result} className="max-w-full max-h-full rounded-2xl shadow-2xl" />}
                  {activeTab === 'video' && <video src={result} controls className="max-w-full max-h-full rounded-2xl shadow-2xl" />}
                  {(activeTab === 'music' || activeTab === 'tts') && (
                    <div className="bg-white/5 p-12 rounded-[40px] border border-white/10 text-center space-y-6">
                      <div className="w-24 h-24 bg-orange-500 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-orange-500/20">
                        <Music size={40} />
                      </div>
                      <audio src={result} controls className="w-full" />
                    </div>
                  )}
                </div>
              ) : analysisResult ? (
                <div className="w-full h-full p-8 overflow-y-auto">
                  <div className="max-w-2xl mx-auto">
                    <div className="flex items-center space-x-2 text-orange-500 mb-6">
                      <Search size={20} />
                      <span className="text-xs font-black uppercase tracking-widest">Analysis Result</span>
                    </div>
                    <div className="prose prose-invert max-w-none text-white/80 leading-relaxed font-medium">
                      {analysisResult}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center opacity-20">
                  <Sparkles size={64} className="mx-auto mb-4" />
                  <p className="font-mono text-xs uppercase tracking-widest">Your content will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
