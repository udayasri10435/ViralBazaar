import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import { aiService } from '../services/aiService';
import { MessageCircle, X, Send, Sparkles, Search, MapPin, Mic, MicOff, Loader2, Image as ImageIcon, Camera, Volume2, VolumeX } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'react-hot-toast';
import { GoogleGenAI, LiveServerMessage, Modality } from "@google/genai";

interface ViralAssistantProps {
  user: User | null;
}

export default function ViralAssistant({ user }: ViralAssistantProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant', text: string, type?: 'search' | 'map' }[]>([
    { role: 'assistant', text: "Hi! I'm ViralAssistant. I can help you find products, locations, or even analyze your photos. How can I help today?" }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);

  // Live API State
  const [session, setSession] = useState<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      let text = '';
      let type: 'search' | 'map' | undefined;

      if (selectedImage) {
        const response = await aiService.analyzeImage(userMsg || "Analyze this image", selectedImage);
        text = response.text;
        setSelectedImage(null);
      } else {
        let latLng;
        try {
          const pos = await new Promise<GeolocationPosition>((res, rej) => navigator.geolocation.getCurrentPosition(res, rej));
          latLng = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
        } catch (e) {
          console.warn("Geolocation failed", e);
        }

        const response = await aiService.chat(userMsg, messages, latLng);
        text = response.text;
        
        // Check for grounding
        const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        type = chunks?.some(c => c.maps) ? 'map' : chunks?.some(c => c.web) ? 'search' : undefined;
      }

      setMessages(prev => [...prev, { role: 'assistant', text, type }]);
    } catch (error) {
      console.error(error);
      toast.error('Assistant failed to respond');
    } finally {
      setLoading(false);
    }
  };

  const toggleLive = async () => {
    if (isLive) {
      session?.close();
      setSession(null);
      setIsLive(false);
      stopRecording();
      return;
    }

    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) throw new Error("API Key missing");
      const ai = new GoogleGenAI({ apiKey });

      const newSession = await ai.live.connect({
        model: "gemini-3.1-flash-live-preview",
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: "You are ViralAssistant, a helpful shopping guide. Talk to the user in a friendly, conversational way.",
        },
        callbacks: {
          onopen: () => {
            setIsLive(true);
            startRecording(newSession);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              playAudio(base64Audio);
            }
          },
          onclose: () => setIsLive(false),
          onerror: (e) => {
            console.error(e);
            setIsLive(false);
          }
        }
      });
      setSession(newSession);
    } catch (error) {
      console.error(error);
      toast.error('Failed to start live session');
    }
  };

  const startRecording = async (activeSession: any) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const audioContext = new AudioContext({ sampleRate: 16000 });
      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);

      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
        }
        const base64Data = btoa(String.fromCharCode(...new Uint8Array(pcmData.buffer)));
        activeSession.sendRealtimeInput({
          audio: { data: base64Data, mimeType: 'audio/pcm;rate=16000' }
        });
      };

      source.connect(processor);
      processor.connect(audioContext.destination);

      audioContextRef.current = audioContext;
      processorRef.current = processor;
      sourceRef.current = source;
      setIsRecording(true);
    } catch (error) {
      console.error(error);
      toast.error('Microphone access denied');
    }
  };

  const stopRecording = () => {
    processorRef.current?.disconnect();
    sourceRef.current?.disconnect();
    audioContextRef.current?.close();
    setIsRecording(false);
  };

  const playAudio = (base64: string) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    audioContext.decodeAudioData(bytes.buffer, (buffer) => {
      const source = audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContext.destination);
      source.start();
    });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setSelectedImage(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAudioUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLoading(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const res = await aiService.transcribeAudio(reader.result as string);
          setInput(res.text);
          toast.success('Audio transcribed!');
        } catch (e) {
          toast.error('Transcription failed');
        } finally {
          setLoading(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 md:bottom-8 right-8 w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center shadow-2xl shadow-orange-500/40 z-40 hover:scale-110 transition-transform"
      >
        <Sparkles className="text-white" size={32} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 100, scale: 0.9 }}
            className="fixed bottom-20 md:bottom-28 right-4 md:right-8 w-[calc(100vw-32px)] md:w-96 h-[600px] bg-neutral-900 border border-white/10 rounded-[40px] shadow-2xl z-50 flex flex-col overflow-hidden"
          >
            {/* Header */}
            <div className="p-6 border-b border-white/10 flex items-center justify-between bg-black/40 backdrop-blur-md">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                  <Sparkles size={20} />
                </div>
                <div>
                  <h3 className="font-black uppercase tracking-tighter">ViralAssistant</h3>
                  <div className="flex items-center space-x-2">
                    <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Online</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <button 
                  onClick={toggleLive}
                  className={`p-2 rounded-xl transition-colors ${isLive ? 'bg-red-500 text-white' : 'bg-white/5 text-white/40 hover:text-white'}`}
                >
                  {isLive ? <Volume2 size={20} /> : <VolumeX size={20} />}
                </button>
                <button onClick={() => setIsOpen(false)} className="p-2 text-white/40 hover:text-white transition-colors">
                  <X size={24} />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-4 rounded-3xl text-sm ${msg.role === 'user' ? 'bg-orange-500 text-white rounded-br-none' : 'bg-white/5 text-white/80 rounded-bl-none'}`}>
                    {msg.text}
                    {msg.type && (
                      <div className="mt-2 flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest opacity-60">
                        {msg.type === 'search' ? <Search size={12} /> : <MapPin size={12} />}
                        <span>Grounded by Google {msg.type === 'search' ? 'Search' : 'Maps'}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-start">
                  <div className="bg-white/5 p-4 rounded-3xl rounded-bl-none">
                    <Loader2 size={16} className="animate-spin text-orange-500" />
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input */}
            <div className="p-6 border-t border-white/10 bg-black/20">
              {selectedImage && (
                <div className="mb-4 relative inline-block">
                  <img src={selectedImage} className="h-20 w-20 object-cover rounded-xl border border-white/20" />
                  <button 
                    onClick={() => setSelectedImage(null)}
                    className="absolute -top-2 -right-2 bg-red-500 text-white p-1 rounded-full shadow-lg"
                  >
                    <X size={12} />
                  </button>
                </div>
              )}
              {isLive ? (
                <div className="flex flex-col items-center justify-center py-4 space-y-4">
                  <div className="relative">
                    <div className="absolute inset-0 bg-red-500 rounded-full animate-ping opacity-20" />
                    <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center relative z-10">
                      <Mic size={32} />
                    </div>
                  </div>
                  <p className="text-xs font-bold text-white/40 uppercase tracking-widest">Listening...</p>
                  <button 
                    onClick={toggleLive}
                    className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:text-white transition-colors"
                  >
                    End Live Conversation
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSend} className="flex items-center space-x-2">
                  <div className="flex-1 relative">
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Ask anything..."
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:border-orange-500 transition-colors"
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center space-x-2">
                      <input type="file" accept="image/*" className="hidden" ref={fileInputRef} onChange={handleImageUpload} />
                      <button 
                        type="button" 
                        onClick={() => fileInputRef.current?.click()}
                        className="text-white/20 hover:text-white transition-colors"
                      >
                        <ImageIcon size={18} />
                      </button>
                      <input type="file" accept="audio/*" className="hidden" ref={audioInputRef} onChange={handleAudioUpload} />
                      <button 
                        type="button" 
                        onClick={() => audioInputRef.current?.click()}
                        className="text-white/20 hover:text-white transition-colors"
                      >
                        <Mic size={18} />
                      </button>
                    </div>
                  </div>
                  <button 
                    type="submit"
                    disabled={!input.trim() || loading}
                    className="bg-white text-black p-3 rounded-2xl hover:bg-orange-500 hover:text-white transition-all disabled:opacity-50"
                  >
                    <Send size={20} />
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
