import { GoogleGenAI, Modality, ThinkingLevel, Type } from "@google/genai";

const getAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY is missing");
  return new GoogleGenAI({ apiKey });
};

// For models requiring user-provided keys (Veo, Lyria, Pro Image)
const getAIWithUserKey = () => {
  const apiKey = process.env.API_KEY || process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("API Key is missing");
  return new GoogleGenAI({ apiKey });
};

export const aiService = {
  // Chat with Search & Maps Grounding
  async chat(message: string, history: any[] = [], latLng?: { latitude: number, longitude: number }) {
    const ai = getAI();
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: "You are ViralAssistant, an expert shopping guide for ViralBazaar. Use Google Search and Maps to find the best products and locations for users.",
        tools: [{ googleSearch: {} }, { googleMaps: {} }],
        toolConfig: {
          retrievalConfig: {
            latLng: latLng
          }
        }
      }
    });

    return await chat.sendMessage({ message });
  },

  // High Thinking for complex tasks
  async complexTask(prompt: string) {
    const ai = getAI();
    return await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH }
      }
    });
  },

  // Image Generation (Flash)
  async generateImageFlash(prompt: string, aspectRatio: "1:1" | "3:4" | "4:3" | "9:16" | "16:9" = "1:1") {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-image-preview",
      contents: prompt,
      config: {
        imageConfig: { aspectRatio }
      }
    });
    
    const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
    return part?.inlineData?.data ? `data:image/png;base64,${part.inlineData.data}` : null;
  },

  // Image Generation (Pro - requires user key)
  async generateImagePro(prompt: string, imageSize: "1K" | "2K" | "4K" = "1K") {
    const ai = getAIWithUserKey();
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-image-preview",
      contents: prompt,
      config: {
        imageConfig: { imageSize }
      }
    });
    
    const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
    return part?.inlineData?.data ? `data:image/png;base64,${part.inlineData.data}` : null;
  },

  // Video Generation (Veo - requires user key)
  async generateVideo(prompt: string, aspectRatio: "16:9" | "9:16" = "16:9", imageBase64?: string) {
    const ai = getAIWithUserKey();
    const config: any = {
      model: 'veo-3.1-fast-generate-preview',
      prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio
      }
    };

    if (imageBase64) {
      config.image = {
        imageBytes: imageBase64.split(',')[1],
        mimeType: 'image/png'
      };
    }

    let operation = await ai.models.generateVideos(config);

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await ai.operations.getVideosOperation({ operation });
    }

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (!downloadLink) return null;

    const response = await fetch(downloadLink, {
      method: 'GET',
      headers: { 'x-goog-api-key': process.env.API_KEY || '' },
    });
    const blob = await response.blob();
    return URL.createObjectURL(blob);
  },

  // Music Generation (Lyria - requires user key)
  async generateMusic(prompt: string, isPro: boolean = false) {
    const ai = getAIWithUserKey();
    const response = await ai.models.generateContentStream({
      model: isPro ? "lyria-3-pro-preview" : "lyria-3-clip-preview",
      contents: prompt,
      config: {
        responseModalities: [Modality.AUDIO]
      }
    });

    let audioBase64 = "";
    let mimeType = "audio/wav";

    for await (const chunk of response) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;
      for (const part of parts) {
        if (part.inlineData?.data) {
          if (!audioBase64 && part.inlineData.mimeType) mimeType = part.inlineData.mimeType;
          audioBase64 += part.inlineData.data;
        }
      }
    }

    const binary = atob(audioBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: mimeType });
    return URL.createObjectURL(blob);
  },

  // TTS
  async textToSpeech(text: string) {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) return null;
    
    const binary = atob(base64Audio);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const blob = new Blob([bytes], { type: 'audio/pcm' }); // Note: TTS returns raw PCM
    return URL.createObjectURL(blob);
  },

  // Analyze Image
  async analyzeImage(prompt: string, imageBase64: string) {
    const ai = getAI();
    return await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: {
        parts: [
          { text: prompt },
          { inlineData: { data: imageBase64.split(',')[1], mimeType: 'image/png' } }
        ]
      }
    });
  },

  // Analyze Video
  async analyzeVideo(prompt: string, videoBase64: string) {
    const ai = getAI();
    return await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: {
        parts: [
          { text: prompt },
          { inlineData: { data: videoBase64.split(',')[1], mimeType: 'video/mp4' } }
        ]
      }
    });
  },

  // Transcription
  async transcribeAudio(audioBase64: string) {
    const ai = getAI();
    return await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { text: "Transcribe this audio exactly." },
          { inlineData: { data: audioBase64.split(',')[1], mimeType: 'audio/wav' } }
        ]
      }
    });
  }
};
