import React from 'react';
import { User } from '../types';
import { Home, PlayCircle, LayoutDashboard, ShoppingBag, User as UserIcon, LogIn, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

interface NavbarProps {
  user: User | null;
  onLogin: () => void;
  onLogout: () => void;
  setView: (view: 'feed' | 'live' | 'dashboard' | 'ai-studio') => void;
  currentView: string;
  cartCount: number;
  onOpenCart: () => void;
}

export default function Navbar({ user, onLogin, onLogout, setView, currentView, cartCount, onOpenCart }: NavbarProps) {
  return (
    <>
      {/* Desktop Navbar */}
      <nav className="fixed top-0 left-0 right-0 h-16 bg-black/80 backdrop-blur-md border-b border-white/10 z-50 px-4 flex items-center justify-between">
        <div 
          className="text-2xl font-black tracking-tighter cursor-pointer hover:text-orange-500 transition-colors"
          onClick={() => setView('feed')}
        >
          VIRALBAZAAR
        </div>

        <div className="hidden md:flex items-center space-x-8">
          <button 
            onClick={() => setView('feed')}
            className={cn(
              "flex items-center space-x-2 text-sm font-medium transition-colors",
              currentView === 'feed' ? "text-orange-500" : "text-white/60 hover:text-white"
            )}
          >
            <Home size={18} />
            <span>Feed</span>
          </button>
          <button 
            onClick={() => setView('live')}
            className={cn(
              "flex items-center space-x-2 text-sm font-medium transition-colors",
              currentView === 'live' ? "text-orange-500" : "text-white/60 hover:text-white"
            )}
          >
            <PlayCircle size={18} />
            <span>Live</span>
          </button>
          {user?.role === 'creator' && (
            <>
              <button 
                onClick={() => setView('dashboard')}
                className={cn(
                  "flex items-center space-x-2 text-sm font-medium transition-colors",
                  currentView === 'dashboard' ? "text-orange-500" : "text-white/60 hover:text-white"
                )}
              >
                <LayoutDashboard size={18} />
                <span>Dashboard</span>
              </button>
              <button 
                onClick={() => setView('ai-studio')}
                className={cn(
                  "flex items-center space-x-2 text-sm font-medium transition-colors",
                  currentView === 'ai-studio' ? "text-orange-500" : "text-white/60 hover:text-white"
                )}
              >
                <Sparkles size={18} />
                <span>AI Studio</span>
              </button>
            </>
          )}
        </div>

        <div className="flex items-center space-x-4">
          <button 
            onClick={onOpenCart}
            className="relative p-2 text-white/80 hover:text-white transition-colors"
          >
            <ShoppingBag size={22} />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 bg-orange-500 text-white text-[10px] font-bold w-4 h-4 flex items-center justify-center rounded-full">
                {cartCount}
              </span>
            )}
          </button>

          {user ? (
            <div className="flex items-center space-x-3">
              <img src={user.photoURL} alt={user.displayName} className="w-8 h-8 rounded-full border border-white/20" />
              <button onClick={onLogout} className="text-xs font-semibold uppercase tracking-widest text-white/40 hover:text-white transition-colors">
                Logout
              </button>
            </div>
          ) : (
            <button 
              onClick={onLogin}
              className="flex items-center space-x-2 bg-white text-black px-4 py-2 rounded-full text-sm font-bold hover:bg-orange-500 hover:text-white transition-all"
            >
              <LogIn size={16} />
              <span>Login</span>
            </button>
          )}
        </div>
      </nav>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-black border-t border-white/10 z-50 flex items-center justify-around px-2">
        <button onClick={() => setView('feed')} className={cn("p-2", currentView === 'feed' ? "text-orange-500" : "text-white/40")}>
          <Home size={24} />
        </button>
        <button onClick={() => setView('live')} className={cn("p-2", currentView === 'live' ? "text-orange-500" : "text-white/40")}>
          <PlayCircle size={24} />
        </button>
        {user?.role === 'creator' && (
          <>
            <button onClick={() => setView('dashboard')} className={cn("p-2", currentView === 'dashboard' ? "text-orange-500" : "text-white/40")}>
              <LayoutDashboard size={24} />
            </button>
            <button onClick={() => setView('ai-studio')} className={cn("p-2", currentView === 'ai-studio' ? "text-orange-500" : "text-white/40")}>
              <Sparkles size={24} />
            </button>
          </>
        )}
        <button onClick={onOpenCart} className="p-2 text-white/40 relative">
          <ShoppingBag size={24} />
          {cartCount > 0 && (
            <span className="absolute top-1 right-1 bg-orange-500 text-white text-[8px] font-bold w-3 h-3 flex items-center justify-center rounded-full">
              {cartCount}
            </span>
          )}
        </button>
        <button className="p-2 text-white/40">
          <UserIcon size={24} />
        </button>
      </nav>
    </>
  );
}
