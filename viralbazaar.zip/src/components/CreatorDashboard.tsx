import React from 'react';
import { User, Product, Order } from '../types';
import { TrendingUp, Users, ShoppingBag, DollarSign, Plus, Package, BarChart3 } from 'lucide-react';
import { motion } from 'motion/react';

interface CreatorDashboardProps {
  user: User;
}

const MOCK_STATS = [
  { label: 'Total Revenue', value: '$47,240', icon: DollarSign, color: 'text-green-500' },
  { label: 'Active Followers', value: '124.5K', icon: Users, color: 'text-blue-500' },
  { label: 'Conversion Rate', value: '8.5%', icon: TrendingUp, color: 'text-orange-500' },
  { label: 'Total Orders', value: '1,890', icon: ShoppingBag, color: 'text-purple-500' },
];

const MOCK_PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Neon Glow Sneakers',
    price: 129.99,
    description: 'High-performance sneakers with integrated LED lighting.',
    image: 'https://picsum.photos/seed/sneakers/400/400',
    creatorId: 'c1',
    stock: 50,
    category: 'Footwear'
  },
  {
    id: 'p2',
    name: 'Classic Black Blazer',
    price: 89.00,
    description: 'A timeless piece for any wardrobe.',
    image: 'https://picsum.photos/seed/blazer/400/400',
    creatorId: 'c2',
    stock: 20,
    category: 'Apparel'
  }
];

export default function CreatorDashboard({ user }: CreatorDashboardProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center space-x-4 mb-4">
            <img src={user.photoURL} alt={user.displayName} className="w-20 h-20 rounded-3xl border-4 border-orange-500 shadow-2xl shadow-orange-500/20" />
            <div>
              <h1 className="text-4xl font-black tracking-tighter uppercase italic">{user.displayName}</h1>
              <p className="text-white/40 font-mono text-sm uppercase tracking-widest">Creator Hub • Verified Partner</p>
            </div>
          </div>
          <div className="space-y-2">
            <h3 className="text-[10px] font-black text-white/40 uppercase tracking-widest">Bio</h3>
            <p className="text-white/60 max-w-xl leading-relaxed">
              {user.bio || "Transforming content into commerce. Join the revolution."}
            </p>
          </div>
        </div>

        <div className="flex space-x-4">
          <button className="bg-white text-black px-6 py-3 rounded-2xl font-bold flex items-center space-x-2 hover:bg-orange-500 hover:text-white transition-all">
            <Plus size={20} />
            <span>New Video</span>
          </button>
          <button className="bg-orange-600 text-white px-6 py-3 rounded-2xl font-bold flex items-center space-x-2 hover:bg-orange-500 transition-all">
            <PlayCircle size={20} />
            <span>Go Live</span>
          </button>
        </div>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        {MOCK_STATS.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-neutral-900 border border-white/10 rounded-3xl p-6"
          >
            <stat.icon className={cn("mb-4", stat.color)} size={24} />
            <p className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1">{stat.label}</p>
            <h3 className="text-2xl font-black tracking-tighter">{stat.value}</h3>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Inventory */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-black uppercase tracking-tighter">My Products</h2>
            <button className="text-xs font-bold uppercase tracking-widest text-orange-500 hover:text-white transition-colors">View All</button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {MOCK_PRODUCTS.map((product) => (
              <div key={product.id} className="bg-neutral-900 border border-white/10 rounded-3xl p-4 flex items-center space-x-4">
                <img src={product.image} alt={product.name} className="w-20 h-20 rounded-2xl object-cover" />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold truncate">{product.name}</h4>
                  <p className="text-orange-500 font-black">${product.price}</p>
                  <div className="flex items-center mt-2 space-x-3">
                    <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Stock: {product.stock}</span>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-white/40">Sales: 124</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="space-y-6">
          <h2 className="text-2xl font-black uppercase tracking-tighter">Recent Sales</h2>
          <div className="bg-neutral-900 border border-white/10 rounded-3xl overflow-hidden">
            {[1, 2, 3, 4, 5].map((_, i) => (
              <div key={i} className="p-4 border-b border-white/5 last:border-0 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-neutral-800" />
                  <div>
                    <p className="text-xs font-bold">Order #829{i}</p>
                    <p className="text-[10px] text-white/40">2 mins ago</p>
                  </div>
                </div>
                <p className="text-sm font-black text-green-500">+$129.99</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function PlayCircle({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polygon points="10 8 16 12 10 16 10 8" />
    </svg>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
