export interface User {
  uid: string;
  displayName: string;
  photoURL: string;
  email: string;
  role: 'creator' | 'shopper' | 'admin';
  bio?: string;
  followersCount: number;
  followingCount: number;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  creatorId: string;
  stock: number;
  category: string;
}

export interface Video {
  id: string;
  creatorId: string;
  videoUrl: string;
  thumbnailUrl: string;
  caption: string;
  productIds: string[];
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  createdAt: any;
}

export interface LiveStream {
  id: string;
  creatorId: string;
  title: string;
  status: 'scheduled' | 'live' | 'ended';
  viewerCount: number;
  featuredProductIds: string[];
  startTime: any;
}

export interface ChatMessage {
  id: string;
  streamId: string;
  userId: string;
  userName: string;
  text: string;
  createdAt: any;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  totalAmount: number;
  status: string;
  createdAt: any;
  influencerId?: string;
}

export interface CartItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  creatorId: string;
}
