import React, { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, query, orderBy, limit, addDoc, serverTimestamp, doc, updateDoc, increment } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { LiveStream, ChatMessage, Product, User } from '../types';
import { Send, Users, Heart, ShoppingBag, X, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '../lib/utils';

interface LiveStreamViewProps {
  user: User | null;
  onAddToCart: (product: Product) => void;
  streamId: string | null;
  onSelectStream: (id: string) => void;
}

const MOCK_STREAMS: LiveStream[] = [
  {
    id: 's1',
    creatorId: 'c1',
    title: 'Summer Collection Launch! 👗✨',
    status: 'live',
    viewerCount: 1240,
    featuredProductIds: ['p1', 'p2'],
    startTime: new Date(),
  },
  {
    id: 's2',
    creatorId: 'c2',
    title: 'Unboxing the latest Tech Gadgets 🎧',
    status: 'live',
    viewerCount: 850,
    featuredProductIds: ['p1'],
    startTime: new Date(),
  }
];

const MOCK_PRODUCTS: Record<string, Product> = {
  'p1': {
    id: 'p1',
    name: 'Neon Glow Sneakers',
    price: 129.99,
    description: 'High-performance sneakers with integrated LED lighting.',
    image: 'https://picsum.photos/seed/sneakers/400/400',
    creatorId: 'c1',
    stock: 50,
    category: 'Footwear'
  },
  'p2': {
    id: 'p2',
    name: 'Classic Black Blazer',
    price: 89.00,
    description: 'A timeless piece for any wardrobe.',
    image: 'https://picsum.photos/seed/blazer/400/400',
    creatorId: 'c2',
    stock: 20,
    category: 'Apparel'
  }
};

export default function LiveStreamView({ user, onAddToCart, streamId, onSelectStream }: LiveStreamViewProps) {
  const [streams, setStreams] = useState<LiveStream[]>([]);
  const [activeStream, setActiveStream] = useState<LiveStream | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const q = query(collection(db, 'liveStreams'), orderBy('startTime', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (snapshot.empty) {
        setStreams(MOCK_STREAMS);
      } else {
        setStreams(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as LiveStream)));
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (streamId) {
      const stream = streams.find(s => s.id === streamId) || MOCK_STREAMS.find(s => s.id === streamId);
      setActiveStream(stream || null);

      const chatQ = query(
        collection(db, 'liveStreams', streamId, 'chat'),
        orderBy('createdAt', 'asc'),
        limit(50)
      );
      const unsubscribe = onSnapshot(chatQ, (snapshot) => {
        setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ChatMessage)));
      });
      return () => unsubscribe();
    } else {
      setActiveStream(null);
      setMessages([]);
    }
  }, [streamId, streams]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newMessage.trim() || !streamId) return;

    try {
      await addDoc(collection(db, 'liveStreams', streamId, 'chat'), {
        streamId,
        userId: user.uid,
        userName: user.displayName,
        text: newMessage,
        createdAt: serverTimestamp(),
      });
      setNewMessage('');
    } catch (error) {
      console.error(error);
    }
  };

  if (!streamId) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-4xl font-black italic uppercase tracking-tighter mb-8">Live Shopping Events</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {streams.map((stream) => (
            <motion.div
              key={stream.id}
              whileHover={{ y: -5 }}
              className="bg-neutral-900 border border-white/10 rounded-3xl overflow-hidden cursor-pointer group"
              onClick={() => onSelectStream(stream.id)}
            >
              <div className="aspect-video relative bg-neutral-800">
                <div className="absolute top-4 left-4 bg-red-600 text-white text-[10px] font-black px-2 py-1 rounded uppercase tracking-widest flex items-center">
                  <div className="w-1.5 h-1.5 bg-white rounded-full mr-1.5 animate-pulse" />
                  Live
                </div>
                <div className="absolute bottom-4 left-4 flex items-center space-x-2 bg-black/40 backdrop-blur-md px-2 py-1 rounded-lg text-[10px] font-bold">
                  <Users size={12} />
                  <span>{stream.viewerCount}</span>
                </div>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center">
                    <Play fill="white" size={32} />
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2">{stream.title}</h3>
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 rounded-full bg-orange-500 overflow-hidden">
                    <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${stream.creatorId}`} alt="Creator" />
                  </div>
                  <span className="text-xs text-white/60">@creator_{stream.creatorId}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[60] bg-black flex flex-col md:flex-row">
      {/* Video Area */}
      <div className="flex-1 relative bg-neutral-900">
        <button 
          onClick={() => onSelectStream('')}
          className="absolute top-4 left-4 z-20 p-2 bg-black/40 backdrop-blur-md rounded-full hover:bg-white/20 transition-colors"
        >
          <X size={24} />
        </button>

        <div className="absolute top-4 right-4 z-20 flex items-center space-x-3">
          <div className="bg-red-600 text-white text-xs font-black px-3 py-1 rounded-full uppercase tracking-widest">Live</div>
          <div className="bg-black/40 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full flex items-center">
            <Users size={14} className="mr-1.5" />
            {activeStream?.viewerCount}
          </div>
        </div>

        <div className="h-full w-full flex items-center justify-center">
          <div className="text-center">
            <Play size={64} className="mx-auto mb-4 text-white/20" />
            <p className="text-white/40 font-mono text-sm uppercase tracking-widest">Live Stream Buffer...</p>
          </div>
        </div>

        {/* Featured Products Overlay */}
        <div className="absolute bottom-6 left-6 right-6 md:right-auto md:w-80 space-y-3">
          {activeStream?.featuredProductIds.map(pid => {
            const product = MOCK_PRODUCTS[pid];
            if (!product) return null;
            return (
              <motion.div 
                key={pid}
                initial={{ x: -50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-3 flex items-center group"
              >
                <img src={product.image} alt={product.name} className="w-14 h-14 rounded-xl object-cover mr-4" />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold truncate">{product.name}</h4>
                  <p className="text-orange-500 font-black text-lg">${product.price}</p>
                </div>
                <button 
                  onClick={() => onAddToCart(product)}
                  className="bg-orange-500 p-3 rounded-xl hover:scale-110 transition-transform"
                >
                  <ShoppingBag size={20} />
                </button>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Chat Area */}
      <div className="w-full md:w-96 bg-neutral-950 border-l border-white/10 flex flex-col h-[40vh] md:h-full">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="font-black uppercase tracking-tighter text-lg">Live Chat</h3>
          <Heart size={20} className="text-white/40" />
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center py-10 opacity-20 italic text-sm">Welcome to the stream! Say hi!</div>
          )}
          {messages.map((msg) => (
            <div key={msg.id} className="flex flex-col">
              <span className="text-[10px] font-black text-orange-500 uppercase tracking-widest mb-0.5">{msg.userName}</span>
              <p className="text-sm text-white/80 leading-relaxed">{msg.text}</p>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>

        <form onSubmit={sendMessage} className="p-4 border-t border-white/10 flex items-center space-x-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder={user ? "Type a message..." : "Login to chat"}
            disabled={!user}
            className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-orange-500 transition-colors"
          />
          <button 
            type="submit"
            disabled={!user || !newMessage.trim()}
            className="bg-white text-black p-3 rounded-xl disabled:opacity-50 hover:bg-orange-500 hover:text-white transition-all"
          >
            <Send size={20} />
          </button>
        </form>
      </div>
    </div>
  );
}
