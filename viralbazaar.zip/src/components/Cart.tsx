import React from 'react';
import { CartItem, User } from '../types';
import { X, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'react-hot-toast';

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onRemove: (id: string) => void;
  user: User | null;
}

export default function Cart({ isOpen, onClose, items, onRemove, user }: CartProps) {
  const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const handleCheckout = async () => {
    if (!user) {
      toast.error('Please login to checkout');
      return;
    }

    if (items.length === 0) return;

    try {
      await addDoc(collection(db, 'orders'), {
        userId: user.uid,
        items,
        totalAmount: total,
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      toast.success('Order placed successfully!');
      onClose();
      // In a real app, clear cart state here
    } catch (error) {
      console.error(error);
      toast.error('Checkout failed');
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
          />
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-neutral-950 border-l border-white/10 z-[101] flex flex-col shadow-2xl"
          >
            <div className="p-6 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <ShoppingBag className="text-orange-500" />
                <h2 className="text-2xl font-black uppercase tracking-tighter">Your Bag</h2>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {items.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-40">
                  <ShoppingBag size={64} strokeWidth={1} />
                  <p className="font-mono text-sm uppercase tracking-widest">Your bag is empty</p>
                </div>
              ) : (
                items.map((item) => (
                  <div key={item.productId} className="flex items-center space-x-4 group">
                    <img src={item.image} alt={item.name} className="w-20 h-20 rounded-2xl object-cover" />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold truncate">{item.name}</h4>
                      <p className="text-orange-500 font-black">${item.price}</p>
                      <p className="text-[10px] text-white/40 uppercase tracking-widest mt-1">Qty: {item.quantity}</p>
                    </div>
                    <button 
                      onClick={() => onRemove(item.productId)}
                      className="p-2 text-white/20 hover:text-red-500 transition-colors"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                ))
              )}
            </div>

            {items.length > 0 && (
              <div className="p-6 border-t border-white/10 space-y-6 bg-neutral-900/50">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-white/40 uppercase tracking-widest">Subtotal</span>
                  <span className="text-2xl font-black tracking-tighter">${total.toFixed(2)}</span>
                </div>
                <button 
                  onClick={handleCheckout}
                  className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center space-x-3 hover:bg-orange-500 hover:text-white transition-all shadow-xl shadow-white/5"
                >
                  <span>Checkout Now</span>
                  <ArrowRight size={20} />
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
